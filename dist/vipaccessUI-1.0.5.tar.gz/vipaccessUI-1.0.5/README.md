# vipaccessUI
A python-tkinter frontend for the python module vipaccess. Which itself is a TOPF implimentation. The same as the symanmtec VIP Access Token.

- Click the number to copy to clipboard

##  TODO:
- wrap with a CLI
- create as module/package with setup 
- publish to pypi

## Demo
![Demo](https://raw.githubusercontent.com/chris17453/vipaccessUI/master/demo.gif)

